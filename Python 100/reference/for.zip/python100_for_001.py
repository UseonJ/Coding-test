# 0부터 9까지 출력하는 for 반복문 예제를 구현하시오.


# [1] : for 반복문
print( '[ 출력 결과 ]' )
print( '-' * 140 )

for i in range(10):
        print( i )
