# 0부터 9까지 숫자가 아래처럼 출력되도록 for 반복문 예제를 구현하시오.
# 0     1       2       3       4       5       6       7       8       9


# [1] : for 반복문
print( '[ 결과 출력 ]' )
print( '-' * 140 )

for i in range(10):
        print( i, end='\t' )

print()
