# 아래의 for 반복문 예제중에서 틀린 곳을 찾아서 말해보시오.


# [1]
for i in range(10):
        print( i )

# [2]
for i in range(10): print( i )

# [3]
for i in range(10):
print( i )

